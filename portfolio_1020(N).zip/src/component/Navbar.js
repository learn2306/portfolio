import React from 'react'
import { Container } from 'react-bootstrap'
import { Link } from 'react-router-dom'

const Navbar = () => {
  return (
	<Container>
		<div className='Navbar'>
		<h1>PORTFOLIO</h1>				
			<div class="context">				
				<Link to='/' className='nav-main'>MAIN</Link><br></br>
				{/* <div>·</div> */}
				<Link to='/about' className='nav-about'>ABOUT</Link><br></br>
				{/* <div>·</div> */}
				<Link to='/' className='nav-work'>WORK</Link><br></br>
				<Link to='/work_01' className='nav-work0'>2023. 01</Link><br></br>
				<Link to='/work_02' className='nav-work0'>02</Link><br></br>
				<Link to='/work_03' className='nav-work0'>03</Link><br></br>
				<Link to='/work_04' className='nav-work0'>04</Link><br></br>
				<Link to='/work_05' className='nav-work0'>05</Link>
			</div>
			
		</div>

	</Container>
	
  )
}

export default Navbar