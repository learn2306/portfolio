import { Container } from 'react-bootstrap';
import './App.css';
import { Route, Routes } from 'react-router-dom';
import Main from './page/Main';
import Navbar from './component/Navbar';
import About from './page/About';
import Work_01 from './page/Work_01';
import Work_02 from './page/Work_02';
import Work_03 from './page/Work_03';
import Work_04 from './page/Work_04';
import Work_05 from './page/Work_05';

function App() {
  return (
    <Container>
      <Routes>
        <Route path='/' element={<Main />} />
        <Route path='/navabar' element={<Navbar />} />
        <Route path='/about' element={<About />} />
        <Route path='/work_01' element={<Work_01 />} />
        <Route path='/work_02' element={<Work_02 />} />
        <Route path='/work_03' element={<Work_03 />} />
        <Route path='/work_04' element={<Work_04 />}></Route>
        <Route path='/work_05' element={<Work_05 />} />
      </Routes>
    </Container>

    
  );
}

export default App;
