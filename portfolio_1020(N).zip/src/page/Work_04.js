import React from 'react'
import { Container } from 'react-bootstrap'
import Navbar from '../component/Navbar'

const Work_04 = () => {
  return (	
	<Container>
		<Navbar />
		<div className='work'>
			<h1>WORK 04</h1>
			<div className='content'>
				<div className='pic'>
					<img src={require('./img/04.jpg')} alt='04' />
				</div>

				<div className='desc'>
					<p>. 2023 10</p>
					<p>. REACT</p>
				</div>
			</div>
		</div>
	</Container>	
  )
}

export default Work_04