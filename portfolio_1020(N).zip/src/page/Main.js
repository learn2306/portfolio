import React from 'react'
import { Container } from 'react-bootstrap'
import Navbar from '../component/Navbar'
import About from './About'
import Work_01 from './Work_01'
import Work_02 from './Work_02'

const Main = () => {
  return (
	<Container>
		<Navbar />	
		<div className='main'>
			<h1>Main 입니다.</h1>
		</div>			
	</Container>	
  )
}

export default Main