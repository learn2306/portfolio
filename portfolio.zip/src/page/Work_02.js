import React from 'react'
import { Container } from 'react-bootstrap'
import Navbar from '../component/Navbar'

const Work_02 = () => {
  return (
	<Container>
		<Navbar />
		<div className='work_02'>
			<h1>WORK 02</h1>
		</div>

	</Container>
	
  )
}

export default Work_02