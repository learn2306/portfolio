import React from 'react'
import { Container } from 'react-bootstrap'
import Navbar from '../component/Navbar'

const About = () => {
  return (
	<Container>
		<Navbar />
		<div className='about'>
			<h1>About</h1>
			<div className='name'>
				Lee Hyun Jin
			</div>

		</div>
		
	</Container>	
  )
}

export default About