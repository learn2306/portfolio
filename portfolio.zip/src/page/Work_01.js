import React from 'react'
import { Container } from 'react-bootstrap'
import Navbar from '../component/Navbar'

const Work_01 = () => {
  return (
	<Container>
		<Navbar />
		<div className='work_01'>
			<h1>WORK 01</h1>
			<div className='pic'>
				{/* <img src={require('img/01.jpg')} alt='01'/> */}
			</div>
		</div>
		
	</Container>
	
  )
}

export default Work_01