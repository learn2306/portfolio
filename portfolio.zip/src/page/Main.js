import React from 'react'
import { Container } from 'react-bootstrap'
import Navbar from '../component/Navbar'
import About from './About'
import Work_01 from './Work_01'
import Work_02 from './Work_02'

const Main = () => {
  return (
	<Container>
		<Navbar />		
		<About />
		<Work_01 />
		<Work_02 />		
	</Container>
	
  )
}

export default Main