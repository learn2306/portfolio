import { Container } from 'react-bootstrap';
import './App.css';
import { Route, Routes } from 'react-router-dom';
import Main from './page/Main';
import Navbar from './component/Navbar';
import About from './page/About';
import Work_01 from './page/Work_01';
import Work_02 from './page/Work_02';

function App() {
  return (
    <Container>
      <Routes>
        <Route path='/' element={<Main />} />
        <Route path='/navabar' element={<Navbar />} />
        <Route path='/about' element={<About />} />
        <Route path='/work_01' element={<Work_01 />} />
        <Route path='/work_02' element={<Work_02 />} />
      </Routes>
    </Container>

    
  );
}

export default App;
