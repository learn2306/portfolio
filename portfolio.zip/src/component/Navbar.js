import React from 'react'
import { Container } from 'react-bootstrap'
import { Link } from 'react-router-dom'

const Navbar = () => {
  return (
	<Container>
		<div className='Navbar'>		
			<h1>Portfolio</h1>	
			<Link to='/about' className='nav-about'>About</Link>			
			<div>·</div>		
			<div>Work</div>
			<Link to='/work_01' className='nav-work'>01</Link>
			<div>·</div>
			<Link to='/work_02' className='nav-work'>02</Link>
			
		</div>

	</Container>
	
  )
}

export default Navbar